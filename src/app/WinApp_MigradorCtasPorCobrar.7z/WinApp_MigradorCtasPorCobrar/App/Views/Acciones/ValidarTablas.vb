﻿Public Class ValidarTablas
    Private Sub ValidarTablas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.MdiParent = Main
    End Sub
End Class