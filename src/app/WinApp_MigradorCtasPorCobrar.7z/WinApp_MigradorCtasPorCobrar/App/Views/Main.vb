﻿Public Class Main

    Private _mainController As MainController
    Private _accionesController As AccionesController
    Public Sub New()
        InitializeComponent()
        Constructor()
    End Sub

    Private Sub Constructor()
        _mainController = New MainController()
        _accionesController = New AccionesController()
    End Sub

    Private Sub Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Show()
        _mainController.Index()
    End Sub

    Private Sub ValidarTablasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ValidarTablasToolStripMenuItem.Click
        _accionesController.ValidarTablas_Show()
    End Sub
End Class