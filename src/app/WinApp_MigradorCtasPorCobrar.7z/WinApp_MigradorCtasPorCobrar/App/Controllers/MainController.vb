﻿Public Class MainController
    Private _accionesController As AccionesController

    Public Sub New()
        MyBase.New()
        Constructor()
    End Sub

    Private Sub Constructor()
        _accionesController = New AccionesController()
    End Sub

    Public Sub Index()
        _accionesController.ValidarTablas_Show()
    End Sub
End Class
