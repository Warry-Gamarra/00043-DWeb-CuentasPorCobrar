﻿Public Class AccionesController
    Public Sub ValidarTablas_Show()
        Dim validaciones As New ValidacionesModel()

        Dim result = validaciones.ExisteTabla("cp_des")

        ValidarTablas.Show()
    End Sub
End Class
