﻿Imports System.Data.SqlClient
Imports Dapper

Public Class ValidacionesModel
    Public Function ExisteTabla(ByVal nombreTabla As String) As ResponseModel
        Dim result As New ResponseModel()

        Using dbConnection As New SqlConnection(Database.TPagosMigracionConnectionString)
            result.IsDone = dbConnection.Execute("SELECT dbo.Func_B_ValidarExisteTablaDatos (@tabla)", New With {.tabla = nombreTabla}, commandType:=CommandType.Text)
        End Using

        If result.IsDone Then
            result.Message = "Ok"
        Else
            result.Message = $"'No se encontró la tabla, {nombreTabla}, requerida para el proceso de migración.\n\r" +
                             $"Debe importar el archivo {nombreTabla}.dbf o {nombreTabla}.xlsx desde el asistente de importación de sql y renombar la tabla como {nombreTabla}"
        End If

        Return result
    End Function
End Class
