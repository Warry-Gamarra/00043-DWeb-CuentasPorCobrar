﻿Public Class ResponseModel
    Private _done As Boolean
    Public Property IsDone() As Boolean
        Get
            Return _done
        End Get
        Set(ByVal value As Boolean)
            _done = value
        End Set
    End Property
    Private _message As String
    Public Property Message() As String
        Get
            Return _message
        End Get
        Set(ByVal value As String)
            _message = value
        End Set
    End Property
End Class
