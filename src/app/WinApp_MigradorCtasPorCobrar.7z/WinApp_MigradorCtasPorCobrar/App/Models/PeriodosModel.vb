﻿Imports System.Data.SqlClient
Imports Dapper

Public Class PeriodosModel
    Public Function ObtenerPeriodos() As List(Of String)
        Dim result As IEnumerable(Of String)

        Using connection As New SqlConnection(Database.TPagosMigracionConnectionString)
            result = connection.Query(Of String)("USP_S_ObtenerPeriodosTemporalPagos", commandType:=CommandType.StoredProcedure)
        End Using

        Return result
    End Function



End Class
