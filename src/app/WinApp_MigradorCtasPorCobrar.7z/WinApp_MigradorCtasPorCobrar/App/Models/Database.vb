﻿Imports System.Configuration

Public Class Database
    Public Shared ReadOnly Property CtasProCobrarConnectionString() As String
        Get
            Return ConfigurationManager.ConnectionStrings("BD_CtasPorCobrarConnection").ConnectionString
        End Get
    End Property

    Public Shared ReadOnly Property TPagosMigracionConnectionString() As String
        Get
            Return ConfigurationManager.ConnectionStrings("BD_MigracionTPConnection").ConnectionString
        End Get
    End Property
End Class
